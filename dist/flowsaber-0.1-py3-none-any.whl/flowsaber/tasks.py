from flowsaber.core.task import ShellTask


class CWLTask(ShellTask):
    pass


class CollectFile(ShellTask):
    pass


class SplitFasta(ShellTask):
    pass


class SplitFastq(ShellTask):
    pass


class SplitText(ShellTask):
    pass
